 package com.peter.whatsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

 public class MainActivity extends AppCompatActivity
{
    private Toolbar mainToolBar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mainToolBar = findViewById(R.id.main_page_app_bar_layout);
        setSupportActionBar(mainToolBar);
        getSupportActionBar().setTitle("WhatsApp");
    }
}
